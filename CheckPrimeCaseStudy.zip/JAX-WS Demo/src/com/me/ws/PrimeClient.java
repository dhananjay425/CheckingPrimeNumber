package com.me.ws;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class PrimeClient {

	public static void main(String[] args) throws Exception{
		URL url = new URL("http://127.0.0.1:8002/myself?wsdl");
		
		QName qname = new QName("http://ws.me.com/","CheckPrimeService");
		
		Service service = Service.create(url, qname);
		
		CheckPrimeService endPoint = service.getPort(CheckPrimeService.class);
		
		Scanner scInput = new Scanner(System.in);
		
		int num = 0 ;
		
		boolean answer;
		
		System.out.print("Enter number: ");
		num = Integer.parseInt(scInput.nextLine());
		
		answer = endPoint.isPrime(num);
		if(answer == true)
		{			
			System.out.println(num + " is a prime number.");
		}
		else
		{
			System.out.println(num + " is not a prime number.");
		}
		
		
		scInput.close();
	}
}