package com.me.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "com.me.ws.CheckPrimeService")
public class CheckPrime{

	public boolean isPrime(int n) {
		
		  if (n <= 1)
	            return false;
	  
	        for (int i = 2; i < n; i++)
	            if (n % i == 0)
	                return false;
	  
	        return true;
	}
}